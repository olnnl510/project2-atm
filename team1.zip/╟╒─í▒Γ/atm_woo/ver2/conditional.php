<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <h1>Conditional</h1>
    <h2>if</h2>
    <?php
    echo '1<br>';
    if(false){
      echo '2-1<br>';
    }
    else {
      echo '2-2<br>';
    }
    echo '2<br>';
    echo '3<br>';
    ?>
  </body>
</html>
