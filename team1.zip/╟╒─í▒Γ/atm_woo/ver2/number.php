<!doctype html>
<html>
<body>
  <h1>Number & Arithmetic Operator</h1>
  <h2>1+1</h2>
  <?php
  echo 1+1;
  ?>
  <h2>2-1</h2>
  <?php
  echo 2-1;
 ?>
 <h2>2*2</h2>
 <?php
 echo 2*2;
 ?>
 <h2>4/2</h2>
 <?php
 echo 4/2;
 ?>
</body>
</html>
