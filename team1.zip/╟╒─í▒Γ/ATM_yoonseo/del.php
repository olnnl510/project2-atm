<?php
//detail.php의 삭제버튼 클릭시 데이터베이스에서 t_board 해당 row 삭제