<!doctype html>
<html>
<body>
  <h1>String & String Operator</h1>
<?php
echo "Hello \"w\"ord";
?>
  <h2>concatenation operator</h2>
  <?php
  echo "Hello "."world";
  ?>
  <h2>String length function</h2>
  <?php
  echo strlen("Hello world");
   ?>
</body>
</html>
