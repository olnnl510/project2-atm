<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <h1>Comparison Operators & Boolean data type </h1>
    <h2>1==1</h2>
      <?php
      var_dump(1==1);
      ?>
    <h2>1>1</h2>
      <?php
      var_dump(1>1);
      ?>
    <h2>1>=1</h2>
      <?php
      var_dump(1>=1);
      ?>
  </body>
</html>
